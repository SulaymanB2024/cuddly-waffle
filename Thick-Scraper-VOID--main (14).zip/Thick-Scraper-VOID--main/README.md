# SEO Audit (Stage 1 MVP)

Public-data-only SEO/site-positioning audit CLI for internal agency use.

## What this Stage 1 build does
- Crawls same-domain pages with robots-respecting behavior by default.
- Parses robots.txt + XML sitemaps (including sitemap indexes).
- Enforces robots crawl-delay when present (while robots are respected).
- Normalizes/deduplicates URLs.
- Extracts on-page SEO metadata from raw HTML.
- Compares raw vs rendered DOM (optional/sample/all modes via Playwright) using the configured crawler user-agent.
- Builds internal link graph metrics (inlinks/outlinks/depth/orphan risk).
- Computes second-pass graph analytics per page (internal PageRank, betweenness, closeness, community id, bridge flag).
- Classifies page types with conservative evidence-weighted rules.
- Audits governance controls for Googlebot, Bingbot, OAI-SearchBot, and Google-Extended.
- Audits restrictive preview controls and raw-vs-rendered noindex/preview-control mismatches.
- Reconciles sampled URL index states with Search Console URL Inspection when credentials are provided.
- Generates explainable issues + heuristic scores with separated preview-control and structured-data-validity dimensions.
- Persists additive score explainability metadata (`scoring_model_version`, `scoring_profile`, `score_explanation_json`) while retaining legacy aliases (`score_version`, `score_profile`, `explanation_json`) for backward-compatible runs and dashboard drill-down.
- Optionally collects PSI and CrUX public metrics.
- Optionally runs a concurrent Common Crawl offsite lane (ranks/domains, verify deferred behind experimental flag) with release-scoped cache and bounded default scheduling.
- Enforces provider key-required behavior in PSI/CrUX runtime paths.
- Applies bounded provider retry/backoff with `Retry-After` support.
- Stores raw provider payloads only when explicitly enabled.
- Supports runtime profiles (`exploratory`, `standard`, `deep`) for crawl/render/provider tuning.
- Persists run observability telemetry (`run_events`) for stage timing, crawl heartbeats, and provider summaries.
- Writes SQLite + CSV exports + Markdown summary report.
- Serves a local interactive dashboard for run-scoped filtering, URL drill-down, and run comparison.

## Not included yet
- SERP/rank tracking, GA4 integrations, vendor SEO APIs, page-level backlink proof workflows, hosted dashboard product surface, distributed crawling.

## Install
```bash
python -m pip install -e .[dev]
# Optional for rendered DOM checks:
python -m playwright install chromium
```

## Run
```bash
python -m seo_audit audit --domain https://void-agency.com --output ./out
```

## Provider keys
```bash
# any one of these can be used
export GOOGLE_API_KEY=your_key
export PSI_API_KEY=your_key
export CRUX_API_KEY=your_key
```
- If shell variables are not set, runtime auto-loads local env files in this order:
	- `.seo_audit.env`
	- `.env.local`
	- `.env`
- Optional explicit file path override:
	- `export SEO_AUDIT_ENV_FILE=/absolute/path/to/env-file`

## Search Console setup (optional)
- URL Inspection reconciliation requires service-account credentials and property access.
- Enable and configure with:
	- `--gsc-enabled`
	- `--gsc-credentials-json /absolute/path/to/service-account.json`
	- `--gsc-property sc-domain:example.com` (optional override)
	- `--gsc-url-limit 200`

## Launch local dashboard
```bash
python -m seo_audit dashboard --db ./out/audit.sqlite --host 127.0.0.1 --port 8765
```

### Compliance-hardening flags (Stage 1.6h)
- Robots bypass requires explicit acknowledgement:
	- `--ignore-robots --i-understand-robots-bypass`
- Provider retry tuning:
	- `--provider-max-retries`
	- `--provider-base-backoff-seconds`
	- `--provider-max-backoff-seconds`
	- `--provider-max-total-wait-seconds`
	- `--provider-respect-retry-after|--provider-ignore-retry-after`
	- `--psi-workers` (bounded PSI worker pool, default `4`)
	- `--provider-rate-limit-rps` (shared provider token refill rate, default `4.0`)
	- `--provider-rate-limit-capacity` (shared provider burst capacity, default `4`)
- Raw payload storage controls:
	- `--store-provider-payloads|--no-store-provider-payloads` (default off)
	- `--payload-retention-days`

### Runtime profiles and observability (Stage 1.6i)
- Profile selection:
	- `--run-profile exploratory|standard|deep`
- Profile-aware overrides (optional):
	- `--max-pages`
	- `--max-render-pages`
	- `--render-mode`
	- `--performance-targets`
	- provider retry/backoff flags from Stage 1.6h
- Crawl heartbeat control:
	- `--crawl-heartbeat-every-pages`
- Provider scheduling behavior:
	- PSI runs with a bounded worker pool.
	- PSI and CrUX collection overlap in the same stage.
	- A shared token-bucket limiter smooths bursts when retries increase.

### Offsite Common Crawl lane (additive)
- Opt-in controls:
	- `--offsite-commoncrawl-enabled|--offsite-commoncrawl-disabled`
	- `--offsite-commoncrawl-mode ranks|domains`
	- `--offsite-commoncrawl-schedule concurrent_best_effort|background_wait|blocking`
	- `--offsite-commoncrawl-release` (default `auto`)
	- `--offsite-commoncrawl-cache-dir` (default `~/.cache/seo_audit/commoncrawl`)
	- `--offsite-commoncrawl-max-linking-domains`
	- `--offsite-commoncrawl-join-budget-seconds`
	- `--offsite-commoncrawl-time-budget-seconds`
	- `--offsite-commoncrawl-allow-cold-edge-download`
	- `--offsite-compare-domain` (repeatable)
	- `--offsite-commoncrawl-experimental-verify` (hidden/experimental gate)
- Scheduling semantics:
	- `concurrent_best_effort`: runs concurrently during this audit process only; tiny end-join budget persists deferred/pending when unfinished.
	- `background_wait`: bounded end-join wait.
	- `blocking`: explicit full-wait power-user mode.
- Domain-mode cold-cache behavior:
	- warm edge cache => full linking-domain discovery,
	- cold edge cache without opt-in => clean `skipped_cold_edge_cache` result,
	- cold edge cache with opt-in => concurrent edge download/work during the same run.
- `verify` mode currently returns `deferred_verify_not_implemented` (page-level proof remains a later bounded feature and is hidden behind an experimental flag).

### JS-rendered site handling
- Crawl keeps a two-step model:
  - always extract raw HTTP HTML facts first,
  - classify raw sufficiency (shell score + reasons),
  - render only likely JS-shell pages.
- Raw and rendered facts are stored separately (`raw_*`, `rendered_*`) and merged into `effective_*` facts for scoring.
- Issue records now include provenance (`raw_only`, `rendered_only`, `both`) to avoid false-confirmed findings on SPA shell HTML.
- Link graph/depth/orphan calculations use effective links; unknown depth is stored as `NULL` (not fallback `99`).
- Render path blocks non-essential assets (images/fonts/media and common trackers) and uses bounded stabilization waits for SPA hydration.

## Test
```bash
pytest -q
```


## CI
- GitHub Actions workflow `.github/workflows/ci.yml` runs on pull requests.
- It runs `ruff check .` and `pytest -q`.

## Output files
In output directory:
- `audit.sqlite`
- `pages.csv`
- `links.csv`
- `issues.csv`
- `scores.csv`
- `page_graph_metrics.csv`
- `performance.csv`
- `crux.csv`
- `sitemaps.csv`
- `robots_rules.csv`
- `run_events.csv`
- `offsite_commoncrawl_summary.csv`
- `offsite_commoncrawl_linking_domains.csv`
- `offsite_commoncrawl_comparisons.csv`
- `offsite_commoncrawl_competitors.csv`
- `report.md`

## Limitations
- Public-data-only; no private analytics context.
- Search Console reconciliation is sampled (`--gsc-url-limit`) and depends on credential/property access.
- Common Crawl offsite intelligence is domain-graph evidence and does not claim exact page-level backlink proof in this milestone.
- Search Console failures or partial responses do not prove deindexing for URLs that were not successfully inspected.
- Render/provider collection can be partial depending on environment and API/key availability.
- Heuristic scoring is explainable but not a ranking prediction model.
- Technical controls improve baseline Google API/crawler behavior, but operational/legal review is still required for deployment context.
